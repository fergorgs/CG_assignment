HOW TO RUN
- rodar o notebook principal "T3 - CG.ipynb"
- a pasta lib possui arquivos com funções auxiliares, usadas ao longo do código principal


CONTROLES
- movimentos da câmera: ASDW e mouse
- FOV: scroll do mouse
- Angulo de rotação do sol: setas esquerda e direita
- Intensidade da luz ambiente: U e P
- Intensidade das luzes interna e externa: (1 e shift+1) e (2 e shift+2), respectivamente


LINK DO VÍDEO NO YOUTUBE:
https://youtu.be/Vp-jSeLEljM


GRUPO
Alexandre Galocha Pinto Junior  10734706
Eduardo Pirro                   10734665
Fernando Gorgulho Fayet         10734407
