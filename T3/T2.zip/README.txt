HOW TO RUN
- rodar o notebook principal "T2 - CG.ipynb"
- a pasta lib possui arquivos com funções auxiliares, usadas ao longo do código principal


CONTROLS
- movimentos da câmera: ASDW
- foco da câmera: mouse


LINK DO VÍDEO NO YOUTUBE:
https://youtu.be/IK04eyyK9eg


GRUPO
Alexandre Galocha Pinto Junior  10734706
Eduardo Pirro                   10734665
Fernando Gorgulho Fayet         10734407
