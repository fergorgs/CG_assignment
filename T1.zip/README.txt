HOW TO RUN
- rodar o notebook principal "T1 - CG.ipynb"
- a pasta lib2d possui arquivos com funções auxiliares, usadas ao longo do código principal


CONTROLS
- movimentos do personagem: ASDW
- rotação do catavendo: left arrow, right arrow
- tamanho da árvore: up arrow, down arrow


LINK DO VÍDEO NO YOUTUBE:
https://youtu.be/0wCIOm7_rCg


GRUPO
Alexandre Galocha Pinto Junior  10734706
Eduardo Pirro                   10734665
Fernando Gorgulho Fayet         10734407
